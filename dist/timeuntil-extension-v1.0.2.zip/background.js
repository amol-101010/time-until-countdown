// MV3 background service worker. Not part of the Flutter build - hand
// written and untouched by build.sh, which only copies Flutter's own
// output files into this folder.
//
// Keeps the toolbar icon's badge showing a live countdown for whichever
// event is pinned in the app (see
// lib/state/providers/extension_badge_provider.dart, which writes the
// pinned event's end time + color here via chrome.storage.local whenever
// the Flutter app is open). This worker does the actual countdown math
// and repaints the badge every minute on its own, so the badge keeps
// ticking down even while no popup/side panel is open.

const ALARM_NAME = 'dash-badge-tick';

chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) updateBadge();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && ('pinnedEventEndMillis' in changes || 'pinnedEventColor' in changes)) {
    updateBadge();
  }
});
chrome.runtime.onStartup.addListener(updateBadge);
chrome.runtime.onInstalled.addListener(updateBadge);

async function updateBadge() {
  const { pinnedEventEndMillis, pinnedEventColor } = await chrome.storage.local.get([
    'pinnedEventEndMillis',
    'pinnedEventColor',
  ]);

  if (!pinnedEventEndMillis) {
    await chrome.action.setBadgeText({ text: '' });
    return;
  }

  await chrome.action.setBadgeText({
    text: formatBadge(pinnedEventEndMillis - Date.now()),
  });
  await chrome.action.setBadgeBackgroundColor({
    color: pinnedEventColor || '#616161',
  });
}

function formatBadge(remainingMs) {
  if (remainingMs <= 0) return 'done';
  const minutes = Math.floor(remainingMs / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (days >= 1) return `${days}d`;
  if (hours >= 1) return `${hours}h`;
  return `${minutes}m`;
}
